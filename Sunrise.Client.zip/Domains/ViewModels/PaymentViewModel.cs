﻿using Sunrise.Client.Infrastructure.Validations;
using Sunrise.Maintenance.Model;
using Sunrise.TransactionManagement.Model.ValueObject;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace Sunrise.Client.Domains.ViewModels
{
    
}
