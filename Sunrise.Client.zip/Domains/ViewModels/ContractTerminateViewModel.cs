﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sunrise.Client.Domains.ViewModels
{
    public class ContractTerminateViewModel
    {
        public ContractTerminateViewModel()
        {
            Description = "";
        }
        public string Id { get; set; }
        public string Description { get; set; }
    }
}
