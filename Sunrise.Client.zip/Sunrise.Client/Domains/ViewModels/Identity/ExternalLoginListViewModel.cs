﻿namespace Sunrise.Client.Domains.ViewModels.Identity
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}