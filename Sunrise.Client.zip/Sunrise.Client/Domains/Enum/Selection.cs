﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sunrise.Client.Domains.Enum
{
    public class SelectionLookup
    {

    }
}