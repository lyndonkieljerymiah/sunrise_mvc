﻿Array.prototype.sum = function (prop) {
    var total = 0;
    for (var i = 0, _len = this.length; i < _len; i++) {
        total += parseInt(this[i][prop]);
    }
    
    return total
}

String.prototype.toCamelCase = function (stopper, startIndex) {
    var retString = "";
    if (stopper) {
        var matches = this.split(stopper);
        if (matches.length > 1) {
            matches = matches.splice(1, matches.length);
        }

        if (matches.length > 0) {
            for (var i = 0; i < matches.length; i++) {
                matches[i] = matches[i].substr(0, 1).toLowerCase() + matches[i].substr(1);
            }
        }
    }

    if (matches.length === 1) {
        return matches.join();
    }
    else {
        return matches.join(".");
    }
}